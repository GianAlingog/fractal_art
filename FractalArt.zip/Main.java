public class Main {
    public static void main(String[] args) {
        new ArtWindow();

        PixImage form = new PixImage("art.png");
        PixImage image1 = new PixImage("image3.png");
        form = ImageFilters.transform(form, image1);
        form.saveImage("art.png");
        form.showImage();
    }
}
