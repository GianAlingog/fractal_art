// Fractal Art by Gian Alingog
// ***************
// Project 3 - Algorithmic Art Project
// 02/17/2024

import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.Random;
import java.awt.Color;

class FractalArt extends JPanel {
    // *****Variables*****

    // DO Change

    private static final int BIGGEST_POWER = 12;
    private static final int SMALLEST_POWER = 3;

    // DO NOT Change
    private static final int BIGGEST_LENGTH = (int) Math.pow(2, BIGGEST_POWER);
    private static final int SMALLEST_LENGTH = (int) Math.pow(2, SMALLEST_POWER);

    // You may switch to this format if you prefer working with bases of two in base ten.
    // private static final int BIGGEST_LENGTH = 512;
    // private static final int SMALLEST_LENGTH = 2;

    // private static final int BIGGEST_POWER = (int) (Math.log(BIGGEST_LENGTH) / Math.log(2));
    // private static final int SMALLEST_POWER = (int) (Math.log(SMALLEST_LENGTH) / Math.log(2));

    private static final int POWER_DIFFERENCE = BIGGEST_POWER - SMALLEST_POWER;

    
    public void paintComponent(Graphics g) {
        
        // Base Square
        createSquare(1280 / 2, 720 / 2, BIGGEST_LENGTH, g);
    }

    private void createSquare(int x, int y, int len, Graphics g) {
        if (len >= SMALLEST_LENGTH) {
            // Creates a square with x, y defining its center.
            Rectangle base = new Rectangle(x, y, len, len);
            drawSquare(base, g);

            createSquare(base.x + len / 2, base.y + len / 2, len / 2, g);
            createSquare(base.x + len / 2, base.y - len / 2, len / 2, g);
            createSquare(base.x - len / 2, base.y + len / 2, len / 2, g);
            createSquare(base.x - len / 2, base.y - len / 2, len / 2, g);
        }
    }

    private void drawSquare(Rectangle square, Graphics g) {
        // Colors are randomized based on the length of the square and an offset
        //
        // The method for converting a value to rgb can be found here:
        // https://stackoverflow.com/a/30309719
        //
        // (Math.log(square.width) / Math.log(2)) / POWER_DIFFERENCE Analysis:
        // - 2^POWER_DIFFERENCE, is the difference in bases of two of the largest and smallest square.
        // - Every square recursively generated has a length of base 2.
        // - Math.log(square.width) / Math.log(2) calculates which power of 2 the length of the current square is.
        // - Then, we divide by 9 to find what the percentage of this power of 2 in relation to the max value.
        Random rnd = new Random(System.currentTimeMillis()); // Randomizer with (relatively) random seed generator
        double colorOffset = rnd.nextDouble();

        double red = Math.min(
                Math.max(0, 1.5 - Math.abs(1 - 4 * ((Math.log(square.width) / Math.log(2)) / POWER_DIFFERENCE - 0.5))),
                1) + colorOffset;
        double green = Math.min(
                Math.max(0, 1.5 - Math.abs(1 - 4 * ((Math.log(square.width) / Math.log(2)) / POWER_DIFFERENCE - 0.25))),
                1) + colorOffset;
        double blue = Math
                .min(Math.max(0, 1.5 - Math.abs(1 - 4 * (Math.log(square.width) / Math.log(2))) / POWER_DIFFERENCE), 1)
                + colorOffset;
        g.setColor(new Color(
                (float) ((red > 1) ? red - 1 : red),
                (float) ((green > 1) ? green - 1 : green),
                (float) ((blue > 1) ? blue - 1 : blue)));

        // Use this instead for single color
        // g.setColor(Color.black);

        // Draw rectangle onto screen
        // Offsets the x and y coordinates to draw it based off its center
        g.drawRect(square.x - square.width / 2, square.y - square.height / 2, square.width, square.height);
    }
}