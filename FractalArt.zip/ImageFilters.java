public class ImageFilters {
    // This method takes in three PixImages (form, image1, image2)
    // Where form is the for which image1 and image2 will be merged
    public static PixImage transform(PixImage form, PixImage image1) {
        PixImage copy = new PixImage(form);
        for (int i = 0; i < copy.height; i++) {
            for (int j = 0; j < copy.width; j++) {
                // If the pixel is white (or blank)
                if (copy.red[i][j] == 255 && copy.green[i][j] == 255 && copy.blue[i][j] == 255) {
                    copy.red[i][j] = image1.red[i][j];
                    copy.green[i][j] = image1.green[i][j];
                    copy.blue[i][j] = image1.blue[i][j];
                } else {
                    copy.red[i][j] = form.red[i][j];
                    copy.green[i][j] = form.green[i][j];
                    copy.blue[i][j] = form.blue[i][j];
                }
            }
        }
        return copy;
    }
}
